import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  AlertCircle,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Loader2,
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { useApp } from '../context/AppContext';
import {
  analyzeSoil,
  explainSoil,
  SoilInput,
} from '../services/api';

const initial: SoilInput = {
  N: 270,
  P: 7.9,
  K: 253,
  pH: 7.48,
  EC: 0.57,
  OC: 0.59,
  S: 3.1,
  Zn: 0.24,
  Fe: 2.49,
  Cu: 0.52,
  Mn: 7.74,
  B: 0.14,
  temperature: 25,
  humidity: 80,
  rainfall: 200,
};

const groups = [
  {
    title: 'Primary Nutrients',
    fields: [
      ['N', 'Nitrogen (N)'],
      ['P', 'Phosphorus (P)'],
      ['K', 'Potassium (K)'],
    ],
  },
  {
    title: 'Soil Properties',
    fields: [
      ['pH', 'pH'],
      ['EC', 'Electrical Conductivity (EC)'],
      ['OC', 'Organic Carbon (OC)'],
      ['S', 'Sulfur (S)'],
      ['Zn', 'Zinc (Zn)'],
      ['Fe', 'Iron (Fe)'],
      ['Cu', 'Copper (Cu)'],
      ['Mn', 'Manganese (Mn)'],
      ['B', 'Boron (B)'],
    ],
  },
  {
    title: 'Environmental Conditions',
    fields: [
      ['temperature', 'Temperature'],
      ['humidity', 'Humidity'],
      ['rainfall', 'Rainfall'],
    ],
  },
] as any[];

export default function Analysis() {
  const { t } = useLanguage();
  const { soil, setSoil, setResult } = useApp();
  const nav = useNavigate();

  const [data, setData] = useState<SoilInput>(soil || initial);
  const [step, setStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const group = groups[step];

  const update = (key: keyof SoilInput, value: string) => {
    setData((current) => ({
      ...current,
      [key]: value === '' ? 0 : Number(value),
    }));
  };

  const submit = async () => {
    setLoading(true);
    setError('');

    try {
      /*
       * The FastAPI /analyze-soil endpoint returns a nested response:
       *   fertility.prediction
       *   fertility.probabilities
       *   crop_recommendation.top_3
       *
       * The Results page uses a flat application result object.
       * Normalize the API response here so the UI, Supabase history,
       * and Results page all use one consistent structure.
       */

      const apiResult = await analyzeSoil(data);

      let shapExplanation: any[] = [];

      try {
        const shapResult = await explainSoil(data);
        shapExplanation = shapResult?.explanation || [];
      } catch {
        // Analysis should still succeed if SHAP fails independently.
        shapExplanation = [];
      }

      const normalizedResult = {
        predicted_fertility:
          apiResult?.fertility?.prediction ||
          apiResult?.predicted_fertility ||
          'Unknown',

        fertility_probabilities:
          apiResult?.fertility?.probabilities ||
          apiResult?.fertility_probabilities ||
          {},

        crop_recommendations:
          apiResult?.crop_recommendation?.top_3 ||
          apiResult?.crop_recommendations ||
          [],

        recommended_crop:
          apiResult?.crop_recommendation?.recommended_crop || '',

        fertilizer_guidance:
          apiResult?.fertilizer_guidance || [],

        shap_explanation:
          shapExplanation,
      };

      setSoil(data);
      setResult(normalizedResult);
      nav('/results');
    } catch (e: any) {
      setError(
        e?.message ||
          'Unable to connect to the analysis server.'
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page">
      <div className="page-head">
        <span className="eyebrow">{t('analysis.eyebrow')}</span>
        <h1>{t('analysis.title')}</h1>
        <p>{t('analysis.desc')}</p>
      </div>

      <div className="notice">
        <AlertCircle size={18} />
        <span>{t('analysis.notice')}</span>
      </div>

      <div className="stepper">
        {groups.map((groupItem, index) => (
          <div
            className={
              index === step
                ? 'step active'
                : index < step
                  ? 'step done'
                  : 'step'
            }
            key={groupItem.title}
          >
            <span>
              {index < step ? (
                <CheckCircle2 size={16} />
              ) : (
                index + 1
              )}
            </span>

            {t(`analysis.group${index + 1}`)}
          </div>
        ))}
      </div>

      <div className="form-card">
        <div className="form-head">
          <div>
            <h2>{t(`analysis.group${step + 1}`)}</h2>

            <p>
              {step === 0
                ? t('analysis.primaryHelp')
                : step === 1
                  ? t('analysis.propertiesHelp')
                  : t('analysis.environmentHelp')}
            </p>
          </div>

          <span className="step-count">
            {step + 1} / 3
          </span>
        </div>

        <div className="form-grid">
          {group.fields.map(
            ([key, label]: any) => (
              <label
                className="field"
                key={key}
              >
                <span>
                  {t(`field.${key}`) || label}
                </span>

                <input
                  type="number"
                  step="any"
                  value={(data as any)[key]}
                  onChange={(event) =>
                    update(
                      key,
                      event.target.value
                    )
                  }
                />

                <small>
                  {key === 'pH'
                    ? 'soil pH'
                    : key === 'temperature'
                      ? '°C'
                      : key === 'humidity'
                        ? '%'
                        : key === 'rainfall'
                          ? 'mm'
                          : ''}
                </small>
              </label>
            )
          )}
        </div>

        {error && (
          <div className="error-box">
            <AlertCircle size={17} />
            {error}
          </div>
        )}

        <div className="form-actions">
          {step > 0 ? (
            <button
              className="btn ghost"
              onClick={() =>
                setStep(step - 1)
              }
            >
              <ChevronLeft size={17} />
              {t('common.back')}
            </button>
          ) : (
            <span />
          )}

          {step < 2 ? (
            <button
              className="btn primary"
              onClick={() =>
                setStep(step + 1)
              }
            >
              {t('common.continue')}
              <ChevronRight size={17} />
            </button>
          ) : (
            <button
              className="btn primary"
              disabled={loading}
              onClick={submit}
            >
              {loading ? (
                <>
                  <Loader2
                    className="spin"
                    size={17}
                  />
                  {t('analysis.analyzing')}
                </>
              ) : (
                <>
                  {t('analysis.analyze')}
                  <ChevronRight size={17} />
                </>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
