import { Link, useNavigate } from 'react-router-dom';
import { ArrowRight, Download, RefreshCw, Save, Info, TrendingUp, Leaf, FlaskConical } from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { useApp } from '../context/AppContext';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';

export default function Results() {
  const { soil, result, saveAnalysis } = useApp();
  const { user } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();

  const localizeClass = (name: string) =>
    name === 'Less Fertile' ? t('results.lessFertile') :
    name === 'Fertile' ? t('results.fertile') :
    name === 'Highly Fertile' ? t('results.highlyFertile') : name;

  if (!result || !soil) {
    return (
      <div className="empty-state">
        <h2>{t('results.noData')}</h2>
        <Link className="btn primary" to="/analysis">{t('results.start')}</Link>
      </div>
    );
  }

  const probabilities = Object.entries(result.fertility_probabilities || {})
    .map(([name, value]) => ({ name, value: Number(value) }))
    .filter((item) => Number.isFinite(item.value));

  const predicted = result.predicted_fertility || 'Unknown';
  const modelProbability = probabilities.find((item) => item.name === predicted)?.value ?? 0;
  const crops = result.crop_recommendations || [];
  const explanation = result.shap_explanation || result.explanation || [];

  const nutrientCards = [
    { key: 'n', name: t('guidance.nitrogen'), value: soil.N, low: soil.N < 200, high: soil.N > 300, within: t('guidance.nWithin'), lowText: t('guidance.nLow'), highText: t('guidance.nHigh') },
    { key: 'p', name: t('guidance.phosphorus'), value: soil.P, low: soil.P < 10, high: soil.P > 50, within: t('guidance.pWithin'), lowText: t('guidance.pLow'), highText: t('guidance.pHigh') },
    { key: 'k', name: t('guidance.potassium'), value: soil.K, low: soil.K < 200, high: soil.K > 500, within: t('guidance.kWithin'), lowText: t('guidance.kLow'), highText: t('guidance.kHigh') },
  ];

  const propertyCards = [
    ['pH', soil.pH, t('results.pHMeaning')],
    ['EC', soil.EC, ''],
    ['OC', soil.OC, ''],
    ['S', soil.S, ''],
    ['Zn', soil.Zn, ''],
    ['Fe', soil.Fe, ''],
    ['Cu', soil.Cu, ''],
    ['Mn', soil.Mn, ''],
    ['B', soil.B, ''],
  ];

  const environmentCards = [
    [t('results.temperature'), soil.temperature, '°C'],
    [t('results.humidity'), soil.humidity, '%'],
    [t('results.rainfall'), soil.rainfall, 'mm'],
  ];

  const replaceCategory = (text: string) => text.replace('{category}', localizeClass(predicted));
  const print = () => window.print();

  return (
    <div className="page print-area">
      <div className="result-top">
        <div>
          <span className="eyebrow">{t('results.eyebrow')}</span>
          <h1>{t('results.title')}</h1>
          <p>{t('results.desc')}</p>
        </div>
        <div className="result-actions">
          <button className="btn ghost" onClick={async () => { if (!user) { navigate('/login'); return; } await saveAnalysis(); }}><Save size={16} /> {t('results.save')}</button>
          <button className="btn ghost" onClick={print}><Download size={16} /> {t('results.pdf')}</button>
          <Link className="btn primary" to="/analysis"><RefreshCw size={16} /> {t('results.new')}</Link>
        </div>
      </div>

      <section className="result-hero farmer-result-hero result-classification-only">
        <div>
          <span className="eyebrow">{t('results.fertility')}</span>
          <div className="fertility-name">{localizeClass(predicted)}</div>
          <p>{t('results.confidence')}</p>
        </div>
        <div className="classification-icon"><Leaf size={40} /></div>
      </section>

      <section className="result-section explanation-card">
        <div className="section-heading compact">
          <span className="eyebrow">{t('results.fertility')}</span>
          <h2>{t('results.meaningTitle')}</h2>
          <p>{replaceCategory(t('results.soilMeaning'))}</p>
        </div>
      </section>

      <section className="result-section probability-section">
        <div className="section-heading compact">
          <span className="eyebrow">{t('results.probability')}</span>
          <h2>{t('results.probabilityTitle')}</h2>
          <p>{t('results.modelProbabilityNote')}</p>
        </div>
        <div className="probability-highlight">
          <strong>{localizeClass(predicted)}</strong>
          <span>{modelProbability}% {t('results.modelProbability')}</span>
        </div>
        <div className="prob-bars">
          {probabilities.map((item) => (
            <div className="prob-row" key={item.name}>
              <div><span>{localizeClass(item.name)}</span><strong>{item.value}%</strong></div>
              <div className="bar"><i style={{ width: `${Math.max(0, Math.min(100, item.value))}%` }} /></div>
            </div>
          ))}
        </div>
        <div className="disclaimer"><Info size={17} /><span>{t('results.probabilityClarifier')}</span></div>
      </section>

      <section className="result-section farmer-summary">
        <div className="section-heading compact">
          <span className="eyebrow">{t('results.farmerSummary')}</span>
          <h2>{t('results.farmerTitle')}</h2>
          <p>{replaceCategory(t('results.farmerSummaryBody'))}</p>
        </div>
      </section>

      <section className="result-section">
        <div className="section-heading compact">
          <span className="eyebrow">{t('results.guidanceEyebrow')}</span>
          <h2>{t('results.nutrientSummary')}</h2>
          <p>{t('results.soilPropertiesNote')}</p>
        </div>
        <div className="guidance-grid nutrient-summary-grid">
          {nutrientCards.map((item) => {
            const status = item.low ? t('guidance.low') : item.high ? t('guidance.high') : t('guidance.within');
            const message = item.low ? item.lowText : item.high ? item.highText : item.within;
            return (
              <div className="guidance-card" key={item.key}>
                <div className="guidance-head"><span>{item.name}</span><span className="status">{status}</span></div>
                <div className="nutrient-value">{item.value}</div>
                <p>{message}</p>
              </div>
            );
          })}
        </div>
        <div className="property-grid">
          {propertyCards.map(([name, value, note]) => (
            <div className="property-card" key={String(name)}>
              <span>{name === 'pH' ? t('field.pH') : name === 'EC' ? t('field.EC') : name === 'OC' ? t('field.OC') : t(`field.${name}`)}</span>
              <strong>{String(value)}</strong>
              {note ? <p>{note}</p> : null}
            </div>
          ))}
        </div>
      </section>

      <section className="result-section">
        <div className="section-heading compact">
          <span className="eyebrow">{t('results.environmentSummary')}</span>
          <h2>{t('results.environmentSummary')}</h2>
          <p>{t('results.environmentNote')}</p>
        </div>
        <div className="environment-grid">
          {environmentCards.map(([name, value, unit]) => (
            <div className="environment-card" key={String(name)}><span>{name}</span><strong>{String(value)} <small>{unit}</small></strong></div>
          ))}
        </div>
      </section>

      <section className="result-section">
        <div className="section-heading compact">
          <span className="eyebrow">{t('results.cropsEyebrow')}</span>
          <h2>{t('results.cropsTitle')}</h2>
          <p>{t('results.cropsNote')}</p>
        </div>
        <div className="crop-grid">
          {crops.slice(0, 3).map((crop: any, index: number) => (
            <div className="crop-card" key={crop.crop || crop.label || index}>
              <span className="crop-rank">0{index + 1}</span>
              <span className="crop-emoji">{['🌾', '🍇', '☕'][index] || '🌱'}</span>
              <h3>{crop.crop || crop.label || 'Crop'}</h3>
              <strong>{Number(crop.probability ?? crop.score ?? 0).toFixed(1)}%</strong>
              <small>{t('results.modelProbability')}</small>
            </div>
          ))}
        </div>
      </section>

      <section className="result-section">
        <div className="section-heading compact">
          <span className="eyebrow">{t('results.guidanceEyebrow')}</span>
          <h2>{t('results.guidanceTitle')}</h2>
        </div>
        <div className="guidance-grid">
          {nutrientCards.map((item) => {
            const status = item.low ? t('guidance.low') : item.high ? t('guidance.high') : t('guidance.within');
            const message = item.low ? item.lowText : item.high ? item.highText : item.within;
            return <div className="guidance-card" key={`guidance-${item.key}`}><div className="guidance-head"><span>{item.name}</span><span className="status">{status}</span></div><p>{message}</p></div>;
          })}
        </div>
        <div className="disclaimer"><Info size={17} /><span>{t('results.guidanceDisclaimer')}</span></div>
      </section>

      <section className="result-section">
        <div className="section-heading compact">
          <span className="eyebrow">{t('results.shapEyebrow')}</span>
          <h2>{t('results.shapTitle')}</h2>
          <p>{t('results.shapNote')}</p>
        </div>
        {explanation.length ? (
          <ResponsiveContainer width="100%" height={360}>
            <BarChart data={explanation.slice(0, 10).map((item: any) => ({ feature: item.feature || item.name || 'Feature', impact: Number(item.shap_value ?? item.value ?? 0) })).filter((item: any) => Number.isFinite(item.impact)).sort((a: any, b: any) => Math.abs(b.impact) - Math.abs(a.impact))} layout="vertical" margin={{ left: 20, right: 30 }}>
              <CartesianGrid strokeDasharray="3 3" /><XAxis type="number" /><YAxis dataKey="feature" type="category" width={70} /><Tooltip /><Bar dataKey="impact" fill="#2f7d4a" radius={[0, 5, 5, 0]} />
            </BarChart>
          </ResponsiveContainer>
        ) : <p className="muted">{t('results.shapUnavailable')}</p>}
      </section>

      <section className="result-section next-steps-card">
        <div className="section-heading compact"><span className="eyebrow">{t('results.whatToDo')}</span><h2>{t('results.whatToDo')}</h2></div>
        <div className="next-steps-grid">
          {[t('results.next1'), t('results.next2'), t('results.next3'), t('results.next4')].map((text, i) => (
            <div className="next-step" key={i}><span>0{i + 1}</span><p>{text}</p></div>
          ))}
        </div>
      </section>

      <div className="disclaimer final-disclaimer"><Info size={18} /><span>{t('results.guidanceDisclaimer')}</span></div>

      <div className="result-bottom">
        <Link className="btn primary" to="/what-if">{t('results.whatIf')} <ArrowRight size={17} /></Link>
        <Link className="btn ghost" to="/history">{t('results.history')} <TrendingUp size={17} /></Link>
      </div>
    </div>
  );
}
