# SoilSense Frontend

Professional multi-page React + TypeScript frontend for the SoilSense soil fertility project.

## Pages
- Home
- Soil Analysis
- Analysis Results
- What-If Analysis
- How It Works
- About

## Languages
English, Telugu, Hindi. The selected language is stored in localStorage.

## Run
```bash
npm install
npm run dev
```

Create `.env` from `.env.example` if the FastAPI backend is not running at `http://localhost:8000`.

```env
VITE_API_URL=http://localhost:8000
```

## Backend CORS
Your FastAPI backend should allow the Vite development origin:

```python
from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```
