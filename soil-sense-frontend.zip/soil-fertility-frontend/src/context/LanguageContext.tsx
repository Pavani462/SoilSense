import {createContext,useContext,useEffect,useMemo,useState,ReactNode} from 'react';
import {en} from '../translations/en'; import {te} from '../translations/te'; import {hi} from '../translations/hi';
export type Lang='en'|'te'|'hi';
const dict={en,te,hi};
type DeepString<T>=T extends string?string:{[K in keyof T]:DeepString<T[K]>};
const C=createContext<{lang:Lang;setLang:(l:Lang)=>void;t:DeepString<typeof en>}>({lang:'en',setLang:()=>{},t:en});
export function LanguageProvider({children}:{children:ReactNode}){const [lang,setLang]=useState<Lang>(()=>(localStorage.getItem('soil-lang') as Lang)||'en');useEffect(()=>localStorage.setItem('soil-lang',lang),[lang]);const t=useMemo(()=>dict[lang] as DeepString<typeof en>,[lang]);return <C.Provider value={{lang,setLang,t}}>{children}</C.Provider>}
export const useLanguage=()=>useContext(C);
