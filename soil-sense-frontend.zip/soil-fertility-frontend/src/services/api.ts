const BASE=import.meta.env.VITE_API_URL||'http://localhost:8000';
async function post<T>(path:string,body:unknown):Promise<T>{const r=await fetch(`${BASE}${path}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});if(!r.ok){const text=await r.text();throw new Error(text||`Request failed (${r.status})`)}return r.json()}
export type Soil={N:number;P:number;K:number;pH:number;EC:number;OC:number;S:number;Zn:number;Fe:number;Cu:number;Mn:number;B:number};
export type Complete=Soil&{temperature:number;humidity:number;rainfall:number};
export const analyze=(x:Complete)=>post<any>('/analyze-soil',x);
export const explain=(x:Soil)=>post<any>('/explain',x);
export const whatIf=(x:Soil&{parameter:string;new_value:number})=>post<any>('/what-if',x);
