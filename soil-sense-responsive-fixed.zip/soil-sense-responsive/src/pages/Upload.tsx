import {useRef,useState} from 'react';
import {Link,useNavigate} from 'react-router-dom';
import {FileUp,AlertTriangle,CheckCircle2,FileText,ArrowRight,Info} from 'lucide-react';
import {useLanguage} from '../context/LanguageContext';
import {useApp} from '../context/AppContext';
import type {SoilInput} from '../services/api';

const keys=['N','P','K','pH','EC','OC','S','Zn','Fe','Cu','Mn','B'] as const;
const defaults:SoilInput={N:0,P:0,K:0,pH:0,EC:0,OC:0,S:0,Zn:0,Fe:0,Cu:0,Mn:0,B:0,temperature:25,humidity:80,rainfall:200};

function extractValues(text:string){
  const found:Partial<Record<typeof keys[number],number>>={};
  for(const key of keys){
    const escaped=key==='pH'?'pH':key;
    const m=text.match(new RegExp(`(?:^|[\\s,;|])${escaped}\\s*[:=,\\-]?\\s*(-?\\d+(?:\\.\\d+)?)`,'im'));
    if(m) found[key]=Number(m[1]);
  }
  return found;
}

export default function Upload(){
  const {t}=useLanguage();
  const {setSoil}=useApp();
  const navigate=useNavigate();
  const ref=useRef<HTMLInputElement>(null);
  const [file,setFile]=useState<File|null>(null);
  const [text,setText]=useState('');
  const [found,setFound]=useState<Partial<Record<typeof keys[number],number>>>({});
  const [notice,setNotice]=useState('');
  const [fileNote,setFileNote]=useState('');

  const processText=(value:string)=>{
    setText(value);
    const values=extractValues(value);
    setFound(values);
    setNotice(Object.keys(values).length?`${Object.keys(values).length} ${t('upload.valuesFound')}`:t('upload.noValues'));
  };

  const handleFile=async(selected:File|null)=>{
    setFile(selected);
    setFound({}); setNotice(''); setFileNote('');
    if(!selected) return;
    const type=selected.type.toLowerCase();
    if(type.includes('text') || selected.name.toLowerCase().endsWith('.csv') || selected.name.toLowerCase().endsWith('.txt')){
      const content=await selected.text();
      processText(content);
      return;
    }
    setFileNote(t('upload.ocrUnavailable'));
  };

  const continueToAnalysis=()=>{
    const missing=keys.filter(k=>found[k]===undefined);
    if(missing.length) return;
    const soil={...defaults,...found} as SoilInput;
    setSoil(soil);
    navigate('/analysis');
  };

  return <div className="page">
    <div className="page-head"><span className="eyebrow">{t('upload.eyebrow')}</span><h1>{t('upload.title')}</h1><p>{t('upload.desc')}</p></div>
    <div className="upload-grid">
      <div className="upload-card" onClick={()=>ref.current?.click()}>
        <input ref={ref} hidden type="file" accept=".txt,.csv,.pdf,image/*" onChange={e=>handleFile(e.target.files?.[0]||null)}/>
        <FileUp size={38}/><h2>{file?file.name:t('upload.choose')}</h2><p>{t('upload.formats')}</p>
        {file && <span className="upload-file-state"><FileText size={14}/>{file.type.includes('pdf')||file.type.startsWith('image/')?t('upload.assistedFile'):t('upload.fileRead')}</span>}
      </div>
      <div className="upload-review">
        <div className="review-head"><div><span className="eyebrow">{t('upload.reviewEyebrow')}</span><h2>{t('upload.reviewTitle')}</h2></div><span className="badge"><AlertTriangle size={14}/>{t('upload.verify')}</span></div>
        <textarea value={text} onChange={e=>processText(e.target.value)} placeholder={'N: 270\nP: 7.9\nK: 253\npH: 7.48\nEC: 0.57\nOC: 0.59\nS: 3.1\nZn: 0.24\nFe: 2.49\nCu: 0.52\nMn: 7.74\nB: 0.14'} />
        {fileNote&&<div className="info-box"><Info size={17}/>{fileNote}</div>}
        {notice&&<div className={Object.keys(found).length?'success-box':'error-box'}>{Object.keys(found).length?<CheckCircle2 size={17}/>:<AlertTriangle size={17}/>} {notice}</div>}
        <div className="extracted-grid">{keys.map(k=><div key={k} className={found[k]!==undefined?'extracted-item found':'extracted-item'}><span>{k}</span><strong>{found[k]!==undefined?found[k]:'—'}</strong></div>)}</div>
        <button className="btn primary" disabled={keys.some(k=>found[k]===undefined)} onClick={continueToAnalysis}>{t('upload.continueAnalysis')} <ArrowRight size={16}/></button>
        <p className="muted">{t('upload.ocrNote')}</p>
      </div>
    </div>
    <div className="disclaimer"><AlertTriangle size={17}/>{t('upload.disclaimer')}</div>
    <div className="upload-footer"><Link className="btn ghost" to="/analysis">{t('upload.manual')}</Link></div>
  </div>;
}
