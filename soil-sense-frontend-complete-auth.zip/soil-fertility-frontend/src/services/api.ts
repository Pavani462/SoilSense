const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:8000';

export type SoilInput = {N:number;P:number;K:number;pH:number;EC:number;OC:number;S:number;Zn:number;Fe:number;Cu:number;Mn:number;B:number;temperature:number;humidity:number;rainfall:number};
export type AnalysisResult = any;

async function request(path:string, body?:unknown){
  const res = await fetch(`${API_BASE}${path}`, {method: body ? 'POST':'GET', headers: body ? {'Content-Type':'application/json'}:undefined, body: body ? JSON.stringify(body):undefined});
  if(!res.ok){ let msg='Request failed'; try{const d=await res.json(); msg=d.detail||msg;}catch{} throw new Error(msg); }
  return res.json();
}
export const analyzeSoil=(data:SoilInput)=>request('/analyze-soil',data);
export const explainSoil=(data:SoilInput)=>request('/explain',data);
export const whatIf=(data:SoilInput & {parameter:string;new_value:number})=>request('/what-if',data);
export const predictFertility=(data:SoilInput)=>request('/predict-fertility',data);
export const recommendCrop=(data:SoilInput)=>request('/recommend-crop',data);
export {API_BASE};
