import {createContext,useContext,useEffect,useMemo,useState,ReactNode} from 'react';
import {en} from '../translations/en'; import {te} from '../translations/te'; import {hi} from '../translations/hi';
export type Lang='en'|'te'|'hi';
const dict={en,te,hi} as any;
const C=createContext<{lang:Lang;setLang:(l:Lang)=>void;t:(key:string)=>string}>({lang:'en',setLang:()=>{},t:(k)=>k});
export function LanguageProvider({children}:{children:ReactNode}){const [lang,setLang]=useState<Lang>(()=>(localStorage.getItem('soil-lang') as Lang)||'en');useEffect(()=>localStorage.setItem('soil-lang',lang),[lang]);const t=useMemo(()=>{const get=(obj:any,key:string):any=>key.split('.').reduce((a,k)=>a?.[k],obj);return (key:string)=>get(dict[lang],key) ?? get(dict.en,key) ?? key},[lang]);return <C.Provider value={{lang,setLang,t}}>{children}</C.Provider>}
export const useLanguage=()=>useContext(C);
