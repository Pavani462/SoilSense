import {createContext,useContext,useEffect,useMemo,useState,ReactNode} from 'react';
import type {SoilInput} from '../services/api';

type SavedAnalysis={id:string;createdAt:string;soil:SoilInput;result:any;name:string};
type Ctx={soil:SoilInput|null;setSoil:(v:SoilInput)=>void;result:any;setResult:(v:any)=>void;saved:SavedAnalysis[];saveAnalysis:(name?:string)=>void;clearCurrent:()=>void};
const C=createContext<Ctx|null>(null);
export function AppProvider({children}:{children:ReactNode}){const [soil,setSoilState]=useState<SoilInput|null>(()=>{try{return JSON.parse(localStorage.getItem('soilsense-soil')||'null')}catch{return null}});const [result,setResultState]=useState<any>(()=>{try{return JSON.parse(localStorage.getItem('soilsense-result')||'null')}catch{return null}});const [saved,setSaved]=useState<SavedAnalysis[]>(()=>{try{return JSON.parse(localStorage.getItem('soilsense-history')||'[]')}catch{return []}});
const setSoil=(v:SoilInput)=>{setSoilState(v);localStorage.setItem('soilsense-soil',JSON.stringify(v))};const setResult=(v:any)=>{setResultState(v);localStorage.setItem('soilsense-result',JSON.stringify(v))};const saveAnalysis=(name='Soil sample')=>{if(!soil||!result)return;const item={id:crypto.randomUUID(),createdAt:new Date().toISOString(),soil,result,name};const next=[item,...saved].slice(0,20);setSaved(next);localStorage.setItem('soilsense-history',JSON.stringify(next))};const clearCurrent=()=>{setSoilState(null);setResultState(null);localStorage.removeItem('soilsense-soil');localStorage.removeItem('soilsense-result')};useEffect(()=>localStorage.setItem('soilsense-history',JSON.stringify(saved)),[saved]);
return <C.Provider value={{soil,setSoil,result,setResult,saved,saveAnalysis,clearCurrent}}>{children}</C.Provider>}
export const useApp=()=>{const c=useContext(C);if(!c)throw new Error('useApp must be used inside AppProvider');return c};
