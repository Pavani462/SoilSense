import { Link, useNavigate } from 'react-router-dom';
import {
  ArrowRight,
  Download,
  RefreshCw,
  Save,
  Info,
  TrendingUp,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';
import { useApp } from '../context/AppContext';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';

export default function Results() {
  const {
    soil,
    result,
    saveAnalysis,
  } = useApp();

  const { user } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();

  const localizeClass = (name: string) =>
    name === 'Less Fertile'
      ? t('results.lessFertile')
      : name === 'Fertile'
        ? t('results.fertile')
        : name === 'Highly Fertile'
          ? t('results.highlyFertile')
          : name;

  if (!result || !soil) {
    return (
      <div className="empty-state">
        <h2>{t('results.noData')}</h2>

        <Link
          className="btn primary"
          to="/analysis"
        >
          {t('results.start')}
        </Link>
      </div>
    );
  }

  const probabilityObject =
    result.fertility_probabilities || {};

  const probs = Object.entries(
    probabilityObject
  )
    .map(([name, value]) => ({
      name,
      value: Number(value),
    }))
    .filter((item) => Number.isFinite(item.value));

  const crops =
    result.crop_recommendations || [];

  const guidance =
    result.fertilizer_guidance || [];

  const explanation =
    result.shap_explanation ||
    result.explanation ||
    [];

  const highestProbability =
    probs.length > 0
      ? Math.max(
          ...probs.map((item) => item.value)
        )
      : 0;

  const print = () => window.print();

  return (
    <div className="page print-area">

      <div className="result-top">
        <div>
          <span className="eyebrow">
            {t('results.eyebrow')}
          </span>

          <h1>{t('results.title')}</h1>

          <p>{t('results.desc')}</p>
        </div>

        <div className="result-actions">

          <button
            className="btn ghost"
            onClick={async () => {
              if (!user) {
                navigate('/login');
                return;
              }

              await saveAnalysis();
            }}
          >
            <Save size={16} />
            {t('results.save')}
          </button>

          <button
            className="btn ghost"
            onClick={print}
          >
            <Download size={16} />
            {t('results.pdf')}
          </button>

          <Link
            className="btn primary"
            to="/analysis"
          >
            <RefreshCw size={16} />
            {t('results.new')}
          </Link>

        </div>
      </div>


      <section className="result-hero">

        <div>
          <span className="eyebrow">
            {t('results.fertility')}
          </span>

          <div className="fertility-name">
            {localizeClass(
              result.predicted_fertility ||
                'Unknown'
            )}
          </div>

          <p>{t('results.confidence')}</p>
        </div>

        <div className="big-score">
          {highestProbability}%
        </div>

      </section>


      <section className="result-section">

        <div className="section-heading compact">

          <span className="eyebrow">
            {t('results.probability')}
          </span>

          <h2>
            {t('results.probabilityTitle')}
          </h2>

        </div>

        <div className="prob-bars">

          {probs.map((probability) => (
            <div
              className="prob-row"
              key={probability.name}
            >
              <div>
                <span>
                  {localizeClass(
                    probability.name
                  )}
                </span>

                <strong>
                  {probability.value}%
                </strong>
              </div>

              <div className="bar">
                <i
                  style={{
                    width: `${Math.max(
                      0,
                      Math.min(
                        100,
                        probability.value
                      )
                    )}%`,
                  }}
                />
              </div>
            </div>
          ))}

        </div>

      </section>


      <section className="result-section">

        <div className="section-heading compact">

          <span className="eyebrow">
            {t('results.cropsEyebrow')}
          </span>

          <h2>
            {t('results.cropsTitle')}
          </h2>

          <p>
            {t('results.cropsNote')}
          </p>

        </div>

        <div className="crop-grid">

          {crops
            .slice(0, 3)
            .map(
              (
                crop: any,
                index: number
              ) => (
                <div
                  className="crop-card"
                  key={
                    crop.crop ||
                    crop.label ||
                    index
                  }
                >
                  <span className="crop-rank">
                    0{index + 1}
                  </span>

                  <span className="crop-emoji">
                    {['🌾', '🍇', '☕'][
                      index
                    ] || '🌱'}
                  </span>

                  <h3>
                    {crop.crop ||
                      crop.label ||
                      'Crop'}
                  </h3>

                  <strong>
                    {Number(
                      crop.probability ??
                        crop.score ??
                        0
                    ).toFixed(1)}
                    %
                  </strong>
                </div>
              )
            )}

        </div>

      </section>


      <section className="result-section">

        <div className="section-heading compact">

          <span className="eyebrow">
            {t('results.guidanceEyebrow')}
          </span>

          <h2>
            {t('results.guidanceTitle')}
          </h2>

        </div>

        <div className="guidance-grid">

          {guidance.map(
            (
              item: any,
              index: number
            ) => (
              <div
                className="guidance-card"
                key={index}
              >

                <div className="guidance-head">

                  <span>
                    {item.nutrient ||
                      item.name ||
                      [
                        'Nitrogen',
                        'Phosphorus',
                        'Potassium',
                      ][index] ||
                      'Guidance'}
                  </span>

                  <span className="status">
                    {item.status ||
                      'Guidance'}
                  </span>

                </div>

                <p>
                  {item.guidance ||
                    item.message ||
                    String(item)}
                </p>

              </div>
            )
          )}

        </div>

        <div className="disclaimer">
          <Info size={17} />
          {t(
            'results.guidanceDisclaimer'
          )}
        </div>

      </section>


      <section className="result-section">

        <div className="section-heading compact">

          <span className="eyebrow">
            {t('results.shapEyebrow')}
          </span>

          <h2>
            {t('results.shapTitle')}
          </h2>

          <p>
            {t('results.shapNote')}
          </p>

        </div>

        {explanation.length ? (
          <ResponsiveContainer
            width="100%"
            height={360}
          >
            <BarChart
              data={explanation
                .slice(0, 10)
                .map((item: any) => ({
                  feature:
                    item.feature ||
                    item.name ||
                    'Feature',

                  impact: Number(
                    item.shap_value ??
                      item.value ??
                      item.impact ??
                      0
                  ),
                }))
                .filter((item: any) =>
                  Number.isFinite(
                    item.impact
                  )
                )
                .sort(
                  (
                    a: any,
                    b: any
                  ) =>
                    Math.abs(b.impact) -
                    Math.abs(a.impact)
                )}
              layout="vertical"
              margin={{
                left: 20,
                right: 30,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" />

              <XAxis type="number" />

              <YAxis
                dataKey="feature"
                type="category"
                width={70}
              />

              <Tooltip />

              <Bar
                dataKey="impact"
                fill="#2f7d4a"
                radius={[0, 5, 5, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        ) : (
          <p className="muted">
            {t(
              'results.shapUnavailable'
            )}
          </p>
        )}

      </section>


      <div className="result-bottom">

        <Link
          className="btn primary"
          to="/what-if"
        >
          {t('results.whatIf')}
          <ArrowRight size={17} />
        </Link>

        <Link
          className="btn ghost"
          to="/history"
        >
          {t('results.history')}
          <TrendingUp size={17} />
        </Link>

      </div>

    </div>
  );
}
